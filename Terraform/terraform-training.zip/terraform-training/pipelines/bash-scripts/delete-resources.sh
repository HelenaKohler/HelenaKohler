#!/bin/bash

az account set -s xxx

if az group show -n "contoso"; then
  az group delete -n "contoso" -y
else
  echo "group contoso does not exist"
fi

if az group show -n "bss-state-file-rg"; then
  az group delete -n "bss-state-file-rg" -y
else 
  echo "group bss-state-file-rg does not exist"
fi

if az group show -n "bss-aci-examples"; then
  az group delete -n "bss-aci-examples" -y
else 
  echo "group bss-aci-examples does not exist"
fi

if az group show -n "bss-portal"; then
  az group delete -n "bss-portal" -y
else 
  echo "group bss-portal does not exist"
fi